import 'package:flutter/material.dart';
import 'package:flutter_2/controller/theme_controller.dart';
import 'package:flutter_2/pages/games/game_controller.dart';
import 'package:flutter_2/pages/main_page/main_screen.dart';
import 'package:flutter_2/pages/people/user_controller.dart';
import 'package:flutter_2/pages/products/product_controller.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

void main() {
  Get.put(ProductController());
  Get.put(UserController());
  Get.put(GameController());

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => ThemeController(),
        )
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    ThemeMode mode = context.watch<ThemeController>().mode;
    return GetMaterialApp(
      themeMode: mode,
      theme: ThemeData(
        brightness: Brightness.light,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.amber,
          foregroundColor: Colors.white,
        ),
        bottomNavigationBarTheme: BottomNavigationBarThemeData(
          unselectedItemColor: Colors.grey,
          selectedItemColor: Colors.blue,
        ),
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
      ),
      home: MainScreen(),
    );
  }
}

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final controller = Get.put(ThemeController());
//     return Obx(
//       () => GetMaterialApp(
//         debugShowCheckedModeBanner: false,
//         theme: ThemeData.light(),
//         themeMode: controller.mode,
//         darkTheme: ThemeData.dark(),
//         initialRoute: RoutesName.splashScreen,
//         getPages: RoutesApp.routes,
//       ),
//     );
//   }
// }
