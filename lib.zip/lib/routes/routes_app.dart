import 'package:flutter_2/pages/dark_get_x/dark_view.dart';
import 'package:flutter_2/pages/dark_get_x/dart_binding.dart';
import 'package:flutter_2/pages/splash/splash_view.dart';
import 'package:flutter_2/routes/routes_name.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';

class RoutesApp {
  static final routes = [
    GetPage(
      name: RoutesName.splashScreen,
      page: () => SplashView(),
    ),
    GetPage(
      name: RoutesName.dark,
      page: () => DarkModeGetXView(),
      binding: DartBinding(),
    ),
  ];
}
