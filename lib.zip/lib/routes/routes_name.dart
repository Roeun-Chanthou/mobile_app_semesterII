class RoutesName {
  RoutesName._();
  static const String dark = '/dark';
  static const String splashScreen = '/splash';
}
