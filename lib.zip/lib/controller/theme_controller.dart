import 'package:flutter/material.dart';

class ThemeController extends ChangeNotifier {
  ThemeMode _mode = ThemeMode.system;
  ThemeMode get mode => _mode;

  int _themeIndex = 0;
  int get themeIndex => _themeIndex;

  void changeToSystem() {
    _themeIndex = 0;
    _mode = ThemeMode.system;
    notifyListeners();
  }

  void changeToLight(){
    _themeIndex = 1;
    _mode = ThemeMode.light;
    notifyListeners();
  }

  void changeToDark(){
    _themeIndex = 2;
    _mode = ThemeMode.dark;
    notifyListeners();
  }
}
