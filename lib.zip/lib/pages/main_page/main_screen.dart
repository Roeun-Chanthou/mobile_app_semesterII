import 'package:flutter/material.dart';
import 'package:flutter_2/controller/theme_controller.dart';
import 'package:flutter_2/pages/games/game_view.dart';
import 'package:flutter_2/pages/people/user_view.dart';
import 'package:flutter_2/pages/products/product_view.dart';
import 'package:provider/provider.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currendIndex = 0;
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      endDrawer: _buildDrawer(),
      body: IndexedStack(
        index: _currendIndex,
        children: [
          ProductView(),
          UserView(),
          GameView(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currendIndex,
        onTap: (value) {
          if (value == 3) {
            _scaffoldKey.currentState!.openEndDrawer();
          } else {
            setState(() {
              _currendIndex = value;
            });
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people),
            label: 'People',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.games),
            label: 'Game',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu),
            label: 'Menu',
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    int themeIndex = context.watch<ThemeController>().themeIndex;
    return Drawer(
      child: ListView(
        children: [
          DrawerHeader(
            child: Icon(
              Icons.face_2,
            ),
          ),
          ExpansionTile(
            title: Text("Theme"),
            initiallyExpanded: true,
            children: [
              ListTile(
                title: Text("To System Mode"),
                leading: Icon(Icons.phone_android),
                onTap: () {
                  context.read<ThemeController>().changeToSystem();
                },
                trailing: themeIndex == 0 ? Icon(Icons.check_circle) : null,
              ),
              ListTile(
                title: Text("To Light Mode"),
                leading: Icon(Icons.light_mode),
                onTap: () {
                  context.read<ThemeController>().changeToLight();
                },
                trailing: themeIndex == 1 ? Icon(Icons.check_circle) : null,
              ),
              ListTile(
                title: Text("To Dark Mode"),
                leading: Icon(Icons.dark_mode),
                onTap: () {
                  context.read<ThemeController>().changeToDark();
                },
                trailing: themeIndex == 2 ? Icon(Icons.check_circle) : null,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
